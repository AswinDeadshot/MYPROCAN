import { Component, OnInit } from '@angular/core';
import { EmployeeService, Employee } from '../employee.service';

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css']
})
export class EmployeeListComponent implements OnInit {

  service:EmployeeService;
  deptData:Employee[]=[];
  

  constructor(service:EmployeeService) {
    this.service=service;
   }

   Delete(id:number)
{
this.service.Delete(id)
this.deptData=this.service.getData();
}
isUpdate:boolean=true
updateData()
{
this.isUpdate=!this.isUpdate
}
Update(data:any)
{
  this.service.Update(data)
  this.deptData=this.service.getData();
}

column:string="id"; 
order:boolean=true;

sort(column:string)
{    
  if(this.column==column )
  {
    this.order=!this.order;
  }
  else
  {
    this.order=true;
    this.column=column;
  }
}
  ngOnInit() {
  this.service.fetchData();
  this.deptData=this.service.getData();
  
  }


}
