import { Component, OnInit } from '@angular/core';
import { EmployeeService, Employee } from '../employee.service';

@Component({
  selector: 'app-search-employee',
  templateUrl: './search-employee.component.html',
  styleUrls: ['./search-employee.component.css']
})
export class SearchEmployeeComponent implements OnInit {

  service:EmployeeService;
  emp:Employee[]=[];
  constructor(service:EmployeeService) 
  {
    this.service=service;
   }
/*
search(data:any)
{
  let idc:number=data.id
  this.emp=this.service.search(idc);
}*/

  ngOnInit() {
  }

}
