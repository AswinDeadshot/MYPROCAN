import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  http: HttpClient;
  fetch: boolean = false;
  dept: Employee[] = []
  constructor(http: HttpClient) {
    this.http = http;
  }
  fetchData() {
    this.http.get("./assets/Employee.json").subscribe(data => {
      if (!this.fetch) {
        this.convert(data);
        this.fetch = true;
      }
    }

    );
  }

  convert(data: any) {
    for (let emp of data) {
      let e = new Employee(emp.id, emp.name, emp.salary);
      this.dept.push(e);
    }
  }
  getData(): Employee[] {
    return this.dept;
  }
  Delete(eid: number) {
    let foundIndex = -1;
    for (let i = 0; i < this.dept.length; i++) {
      let e = this.dept[i];
      if (e.id == eid) {
        foundIndex = i;
        break;
      }
    }
    this.dept.splice(foundIndex,1)
  }
  add(e:Employee){
    //
    //adding employee at end in array
    //  
    this.dept.push(e);
  }

  Update(data:Employee)
{
let eid=data.id;
for(let i=0;i<this.dept.length;i++)
{
  if(eid==this.dept[i].id)
  {
    this.dept[i].salary=data.salary
    this.dept[i].name=data.name
    break;
  }
}
}

/*
search(data:number):Employee[]
{
  let employee:Employee[]=[];
  let o:Employee
var flag=0;
for(let e=0;e<this.dept.length;e++){
  o=this.dept[e]
  console.log(o)
  if(data==o.id)
  {
employee.push(o);
flag=1;
console.log(flag)
  }
}
if(flag==0)
alert(data+"doesnt exist")
return employee;
}*/

}

export class Employee {
  id: number;
  name: string;
  salary: number;
  constructor(id: number, name: string, salary: number) {

    this.id = id;
    this.name = name;
    this.salary = salary;

  }
}